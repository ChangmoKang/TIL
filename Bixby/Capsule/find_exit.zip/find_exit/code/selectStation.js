// 내부 모듈
var http = require('http');
var fail = require('fail');
var dates = require('dates');
var config = require('config');
var secret = require('secret');
var console = require('console');

// DB
var nationalStation = require('./data/nationalStation.js')

// 함수호출
var calcDistance = require('./function/calcDistance.js')
var priorityPush = require('./function/priorityPush.js')


module.exports = function selectStation (stationName, userLocation) {
  let correctResults = []
  let similarResults = []
  Object.keys(nationalStation).forEach(region => {
    Object.keys(nationalStation[region]).forEach(each => {
      location = {
        'longitude': nationalStation[region][each]['location'][0],
        'latitude': nationalStation[region][each]['location'][1]
      }

      if (each == stationName) {
        correctResults = priorityPush(correctResults, {
          'regionName': region,
          'name': each,
          'location': location,
          'distance': calcDistance(location, userLocation)
        })
      }
      else if (each.includes(stationName.slice(0, -1))) {
        similarResults = priorityPush(similarResults, {
          'regionName': region,
          'name': each,
          'location': location,
          'distance': calcDistance(location, userLocation)
        })
      }
    })
  })

  if (correctResults.length !== 0) {
    Object.keys(correctResults).forEach(el => {
      if (correctResults[el].distance > 1) {
        correctResults[el].distance = correctResults[el].distance.toFixed(2) + 'km'
      } else {
        correctResults[el].distance = (correctResults[el].distance*1000).toFixed(0) + 'm'
      }
    })
    return correctResults
  } else if (similarResults.length !== 0) {
    Object.keys(similarResults).forEach(el => {
      if (similarResults[el].distance > 1) {
        similarResults[el].distance = similarResults[el].distance.toFixed(2) + 'km'
      } else {
        similarResults[el].distance = (similarResults[el].distance*1000).toFixed(0) + 'm'
      }
    })
    return similarResults
  } else {
    return null
  }
}
