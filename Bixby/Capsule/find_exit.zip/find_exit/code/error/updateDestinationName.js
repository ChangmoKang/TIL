module.exports.function = function updateDestinationName (destinationName) {
  return destinationName
}
